<?xml version="1.0" ?><!DOCTYPE TS><TS language="ug" version="2.1">
<context>
    <name>HomePage</name>
    <message>
        <source>Drag font file here</source>
        <translation>فونتنى تاتىپ ئەكىرىڭ</translation>
    </message>
    <message>
        <source>Select file</source>
        <translation>ھۆججەت تاللاش</translation>
    </message>
</context>
<context>
    <name>ListItem</name>
    <message>
        <source>Installed</source>
        <translation>قاچىلاش</translation>
    </message>
    <message>
        <source>Other version installed: %1</source>
        <translation>باشقا نەشىردىكىللىرى 1% قاچىلاندى</translation>
    </message>
    <message>
        <source>Installing</source>
        <translation>قاچىلاش</translation>
    </message>
    <message>
        <source>Same version installed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <source>Deepin Font Installer</source>
        <translation>فونت قاچىلىغۇچ</translation>
    </message>
    <message>
        <source>Deepin Font Installer is used to install and uninstall font file for users with bulk install function.</source>
        <translation>Deepin فونت قاچىلىغۇچ فوننىت ھۆججىتىنى قاچىلايدۇ ۋە ئۆچۈرىدۇ، ئابونتلار ئۈچۈن يەنە باشقا ئىقتىدارلار قوشۇلغان</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Deepin Font Installer</source>
        <translation>فونت قاچىلىغۇچ</translation>
    </message>
    <message>
        <source>Bulk Install</source>
        <translation>كۆپ قاچىلاش</translation>
    </message>
    <message>
        <source>Dark theme</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MultiFilePage</name>
    <message>
        <source>Install</source>
        <translation>قاچىلاش</translation>
    </message>
    <message>
        <source>Installed successfully</source>
        <translation>قاچىلاش تامام</translation>
    </message>
    <message>
        <source>View font directory</source>
        <translation>فونت مۇندەرىجىسىنى كۆرۈش</translation>
    </message>
    <message>
        <source>Refreshing font cache, please wait...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SingleFilePage</name>
    <message>
        <source>Install</source>
        <translation>قاچىلاش</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>چىقىرۋېتىش</translation>
    </message>
    <message>
        <source>Reinstall</source>
        <translation>قايتا قاچىلاش</translation>
    </message>
    <message>
        <source>View font directory</source>
        <translation>فونت مۇندەرىجىسىنى كۆرۈش</translation>
    </message>
    <message>
        <source>Style: </source>
        <translation>ھالىتى:</translation>
    </message>
    <message>
        <source>Type: </source>
        <translation>تىپى:</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation>نەشىرى:</translation>
    </message>
    <message>
        <source>Copyright: </source>
        <translation>نەشىر ھوقۇقى:</translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>بايانى:</translation>
    </message>
    <message>
        <source>Same version installed</source>
        <translation>ئوخشاش نەشىردىكىسى قاچىلاندى</translation>
    </message>
    <message>
        <source>Installed successfully</source>
        <translation>قاچىلاش تامام</translation>
    </message>
    <message>
        <source>Removed successfully</source>
        <translation>ئۆچۈرۈش تامام</translation>
    </message>
    <message>
        <source>Other version installed: %1</source>
        <translation>باشقا نەشىردىكىللىرى 1% قاچىلاندى</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>تامام</translation>
    </message>
</context>
</TS>