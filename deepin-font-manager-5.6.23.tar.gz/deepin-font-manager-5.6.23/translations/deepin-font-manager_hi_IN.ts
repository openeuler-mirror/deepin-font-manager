<?xml version="1.0" ?><!DOCTYPE TS><TS language="hi_IN" version="2.1">
<context>
    <name>HomePage</name>
    <message>
        <source>Drag font file here</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select file</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ListItem</name>
    <message>
        <source>Installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Other version installed: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Installing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Same version installed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <source>Deepin Font Installer</source>
        <translation>डीपिन मुद्रलिपि इंस्टॉलर</translation>
    </message>
    <message>
        <source>Deepin Font Installer is used to install and uninstall font file for users with bulk install function.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Deepin Font Installer</source>
        <translation>डीपिन मुद्रलिपि इंस्टॉलर</translation>
    </message>
    <message>
        <source>Bulk Install</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Dark theme</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MultiFilePage</name>
    <message>
        <source>Install</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Installed successfully</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>View font directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Refreshing font cache, please wait...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SingleFilePage</name>
    <message>
        <source>Install</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reinstall</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>View font directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Style: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Type: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Version: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Copyright: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Description: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Same version installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Installed successfully</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Removed successfully</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Other version installed: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Done</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>