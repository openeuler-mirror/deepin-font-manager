<?xml version="1.0" ?><!DOCTYPE TS><TS language="mn" version="2.1">
<context>
    <name>HomePage</name>
    <message>
        <source>Drag font file here</source>
        <translation>Фонт файл энд чирнэ үү</translation>
    </message>
    <message>
        <source>Select file</source>
        <translation>Файл сонгох</translation>
    </message>
</context>
<context>
    <name>ListItem</name>
    <message>
        <source>Installed</source>
        <translation>Суулаа</translation>
    </message>
    <message>
        <source>Other version installed: %1</source>
        <translation>%1: хувилбар суусан байна</translation>
    </message>
    <message>
        <source>Installing</source>
        <translation>Суулгаж байна</translation>
    </message>
    <message>
        <source>Same version installed</source>
        <translation>Адил хувилбар суусан байна</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <source>Deepin Font Installer</source>
        <translation>Дээпин фонт суулгагч</translation>
    </message>
    <message>
        <source>Deepin Font Installer is used to install and uninstall font file for users with bulk install function.</source>
        <translation>Дээпин фонт суулгагчыг олноор фонт суулгах болон устгахад ашигладаг.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Deepin Font Installer</source>
        <translation>Дээпин фонт суулгагч</translation>
    </message>
    <message>
        <source>Bulk Install</source>
        <translation>Олноор суулгах</translation>
    </message>
    <message>
        <source>Dark theme</source>
        <translation>Хар ѳнгѳ</translation>
    </message>
</context>
<context>
    <name>MultiFilePage</name>
    <message>
        <source>Install</source>
        <translation>Суулгах</translation>
    </message>
    <message>
        <source>Installed successfully</source>
        <translation>Амжилттай суулаа</translation>
    </message>
    <message>
        <source>View font directory</source>
        <translation>Фонтны хавтас харах</translation>
    </message>
    <message>
        <source>Refreshing font cache, please wait...</source>
        <translation>Фонт нѳѳцийг дахин уншиж байна, түр хүлээнэ үү...</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Үл мэдэгдэх</translation>
    </message>
</context>
<context>
    <name>SingleFilePage</name>
    <message>
        <source>Install</source>
        <translation>Суулгах</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Устгах</translation>
    </message>
    <message>
        <source>Reinstall</source>
        <translation>Дахин суулга</translation>
    </message>
    <message>
        <source>View font directory</source>
        <translation>Фонтны хавтас харах</translation>
    </message>
    <message>
        <source>Style: </source>
        <translation>Загвар:</translation>
    </message>
    <message>
        <source>Type: </source>
        <translation>Тѳрѳл:</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation>Хувилбар:</translation>
    </message>
    <message>
        <source>Copyright: </source>
        <translation>Эрх:</translation>
    </message>
    <message>
        <source>Description: </source>
        <translation>Тайлбар:</translation>
    </message>
    <message>
        <source>Same version installed</source>
        <translation>Адил хувилбар суусан байна</translation>
    </message>
    <message>
        <source>Installed successfully</source>
        <translation>Амжилттай суулаа</translation>
    </message>
    <message>
        <source>Removed successfully</source>
        <translation>Устгагдлаа</translation>
    </message>
    <message>
        <source>Other version installed: %1</source>
        <translation>%1: хувилбар суусан байна</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Болсон</translation>
    </message>
</context>
</TS>